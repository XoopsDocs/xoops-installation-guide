### _XOOPS Documentation Series_
![logoXoops.jpg](assets/logoXoops.jpg)

# XOOPS Marquee 2.50
#### for XOOPS 2.5.7
  
      
![logoModule.png](assets/logoModule.png)
            
                
                
    
## User Manual
  
  
  
  
  
© 2014 The XOOPS Project (www.xoops.org)    
  

## Module Purpose 

 
This module is for .....

 
![image001.png](assets/image001.png)
*Figure 1: Main view of the Marquee Module (Admin side)*